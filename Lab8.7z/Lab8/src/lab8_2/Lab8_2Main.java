package lab8_2;

class Lab8_2Main
{
  
public static void main(String args[]){  
Lab8_2 m1=new Lab8_2();  
Thread t1 =new Thread(m1);  
t1.start();  
 }  
}  